#!/usr/bin/env python
""" Test Package
"""

def hello_world(name="world"):
    """Thing to test with"""
    print(f"v2 {name}")
