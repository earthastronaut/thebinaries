from setuptools import setup
setup(
    name="testymctestface",
    version="v1.0.0",
    author="Dylan",
    description="Test packaging",
    long_description="Test packaging all",
    long_description_content_type='text/markdown',
    py_modules=['testymctestface'],
    python_requires='>=2.7',
)
